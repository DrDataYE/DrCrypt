# DrCrypt

### to install:
```bash
pip3 install drcrypt
```
