class XOR:
    def my_test_function(self):
        return "test"
