from .crypt import XOR
